package com.ageadgmc.shamcash;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String START_URL = "https://ageadchamcash.free.je/sham-cash/";
    private static final String TRUSTED_HOST = "ageadchamcash.free.je";
    private static final int FILE_CHOOSER_REQUEST = 7412;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;
    private final ArrayList<Dialog> popupDialogs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.rgb(15, 23, 42));
        getWindow().setNavigationBarColor(Color.rgb(15, 23, 42));
        WindowInsetsControllerCompat insetsController = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        insetsController.setAppearanceLightStatusBars(false);
        insetsController.setAppearanceLightNavigationBars(false);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(241, 245, 249));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(241, 245, 249));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return windowInsets;
        });
        setContentView(root);

        configureWebView(webView, null, true);
        CookieManager.getInstance().setAcceptCookie(true);
        webView.loadUrl(START_URL);
    }

    private void configureWebView(WebView target, Dialog parentDialog, boolean allowPopups) {
        WebSettings settings = target.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(allowPopups);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        target.setOverScrollMode(View.OVER_SCROLL_NEVER);
        target.addJavascriptInterface(new AndroidBridge(target), "AndroidApp");
        target.setWebViewClient(createWebViewClient(target, parentDialog));
        target.setWebChromeClient(createWebChromeClient(target, allowPopups));
        target.setDownloadListener(createDownloadListener());
    }

    private WebViewClient createWebViewClient(WebView target, Dialog parentDialog) {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(request.getUrl(), parentDialog);
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    return handleNavigation(Uri.parse(url), parentDialog);
                } catch (Exception e) {
                    return true;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                try {
                    view.evaluateJavascript(androidBridgePatchScript(), null);
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    String errorPage = "<!doctype html><html lang='ar' dir='rtl'><meta charset='utf-8'>"
                            + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                            + "<body style='font-family:Tahoma,Arial;background:#f1f5f9;color:#0f172a;padding:28px;text-align:center'>"
                            + "<h2>تعذر الاتصال بحاسبة شام كاش</h2>"
                            + "<p>تحقق من اتصال الإنترنت ثم أعد المحاولة.</p>"
                            + "<button style='padding:12px 20px;background:#4f46e5;color:white;border:0;border-radius:10px;font-size:16px' onclick=\"location.href='"
                            + START_URL + "'\">إعادة المحاولة</button></body></html>";
                    view.post(() -> view.loadDataWithBaseURL(START_URL, errorPage, "text/html", "UTF-8", null));
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) {
                handler.cancel(); // لا نتجاوز أخطاء شهادة HTTPS مطلقًا.
            }
        };
    }

    private boolean handleNavigation(Uri uri, Dialog parentDialog) {
        if (uri == null) return true;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        if (("https".equals(scheme) && TRUSTED_HOST.equals(host)) || "about".equals(scheme) || "blob".equals(scheme) || "data".equals(scheme)) {
            return false;
        }
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme) || "tel".equals(scheme) || "smsto".equals(scheme)) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                if (parentDialog != null) parentDialog.dismiss();
            } catch (Exception e) {
                toast("لا يوجد تطبيق مناسب لفتح هذا الرابط.");
            }
            return true;
        }
        if ("intent".equals(scheme)) {
            try {
                Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                startActivity(intent);
            } catch (Exception ignored) {
                toast("تعذر فتح الرابط الخارجي.");
            }
            return true;
        }
        return true;
    }

    private WebChromeClient createWebChromeClient(WebView target, boolean allowPopups) {
        return new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = filePathCallback;
                try {
                    Intent pick = fileChooserParams.createIntent();
                    startActivityForResult(Intent.createChooser(pick, "اختر ملفًا"), FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    pendingFileCallback = null;
                    filePathCallback.onReceiveValue(null);
                    toast("تعذر فتح اختيار الملفات.");
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                if (isFinishing()) { result.cancel(); return true; }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("حسنًا", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                if (isFinishing()) { result.cancel(); return true; }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("موافق", (dialog, which) -> result.confirm())
                        .setNegativeButton("إلغاء", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                if (isFinishing()) { result.cancel(); return true; }
                EditText input = new EditText(MainActivity.this);
                input.setSingleLine(true);
                if (defaultValue != null) input.setText(defaultValue);
                FrameLayout box = new FrameLayout(MainActivity.this);
                int pad = (int) (20 * getResources().getDisplayMetrics().density);
                box.setPadding(pad, pad / 2, pad, 0);
                box.addView(input, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(box)
                        .setPositiveButton("موافق", (dialog, which) -> result.confirm(input.getText().toString()))
                        .setNegativeButton("إلغاء", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                input.requestFocus();
                return true;
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (!allowPopups) return false;
                showPopupWindow(resultMsg);
                return true;
            }

            @Override
            public void onCloseWindow(WebView window) {
                dismissPopupFor(window);
            }
        };
    }

    private void showPopupWindow(Message resultMsg) {
        WebView popup = new WebView(this);
        Dialog popupDialog = new Dialog(this);
        popupDialog.setTitle("حاسبة شام كاش");
        popupDialog.setContentView(popup);
        popupDialogs.add(popupDialog);
        configureWebView(popup, popupDialog, false);
        popupDialog.setOnDismissListener(dialog -> {
            popupDialogs.remove(popupDialog);
            try { popup.stopLoading(); popup.destroy(); } catch (Exception ignored) {}
        });
        popupDialog.show();
        Window window = popupDialog.getWindow();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.setStatusBarColor(Color.rgb(15, 23, 42));
            window.setNavigationBarColor(Color.rgb(15, 23, 42));
        }
        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(popup);
        resultMsg.sendToTarget();
    }

    private void dismissPopupFor(WebView popup) {
        for (int i = popupDialogs.size() - 1; i >= 0; i--) {
            Dialog dialog = popupDialogs.get(i);
            if (dialog.isShowing()) {
                dialog.dismiss();
                return;
            }
        }
    }

    private DownloadListener createDownloadListener() {
        return (url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || url.startsWith("blob:") || url.startsWith("data:")) return;
            try {
                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setTitle("تنزيل من حاسبة شام كاش");
                request.setDescription("جارٍ تنزيل الملف");
                if (mimeType != null && !mimeType.isEmpty()) request.setMimeType(mimeType);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) request.addRequestHeader("Cookie", cookies);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeFilename(contentDisposition, url));
                manager.enqueue(request);
                toast("بدأ تنزيل الملف. ستجده في مجلد التنزيلات.");
            } catch (Exception e) {
                toast("تعذر تنزيل الملف من الرابط.");
            }
        };
    }

    private String safeFilename(String contentDisposition, String url) {
        String name = "ShamCash_File";
        if (contentDisposition != null) {
            int at = contentDisposition.toLowerCase(Locale.ROOT).indexOf("filename=");
            if (at >= 0) name = contentDisposition.substring(at + 9).replace("\"", "").trim();
        }
        if ("ShamCash_File".equals(name)) {
            try {
                String path = Uri.parse(url).getLastPathSegment();
                if (path != null && !path.trim().isEmpty()) name = path;
            } catch (Exception ignored) {}
        }
        name = name.replaceAll("[^A-Za-z0-9._-]", "_");
        return name.isEmpty() ? "ShamCash_File" : name;
    }

    private String androidBridgePatchScript() {
        return "(function(){try{" +
                "if(!window.AndroidApp||window.__shamCashNativeReady)return;window.__shamCashNativeReady=true;" +
                "try{navigator.canShare=function(d){return !!(d&&d.files&&d.files.length>0)};}catch(e){}" +
                "try{navigator.share=function(d){d=d||{};if(d.files&&d.files.length){var f=d.files[0];var r=new FileReader();r.onload=function(){window.AndroidApp.shareDataUrl(String(r.result||''),f.name||'ShamCash_File',f.type||'application/octet-stream',d.title||'مشاركة من حاسبة شام كاش',d.text||'')};r.readAsDataURL(f);return Promise.resolve()}window.AndroidApp.shareText(d.title||'حاسبة شام كاش',d.text||'');return Promise.resolve()};}catch(e){}" +
                "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;if(!a)return;var h=a.href||'';if(h.indexOf('blob:')!==0)return;e.preventDefault();e.stopPropagation();fetch(h).then(function(x){return x.blob()}).then(function(b){var r=new FileReader();r.onload=function(){window.AndroidApp.saveDataUrl(String(r.result||''),a.download||'ShamCash_File',b.type||'application/octet-stream')};r.readAsDataURL(b)}).catch(function(){alert('تعذر حفظ الملف. حاول مرة أخرى.')});},true);" +
                "window.print=function(){window.AndroidApp.printCurrentPage()};" +
                "}catch(e){}})();";
    }

    private final class AndroidBridge {
        private final WebView target;
        AndroidBridge(WebView target) { this.target = target; }

        @JavascriptInterface
        public void saveDataUrl(String dataUrl, String filename, String mimeType) {
            runOnUiThread(() -> saveDataUrlInternal(dataUrl, filename, mimeType));
        }

        @JavascriptInterface
        public void shareDataUrl(String dataUrl, String filename, String mimeType, String title, String text) {
            runOnUiThread(() -> shareDataUrlInternal(dataUrl, filename, mimeType, title, text));
        }

        @JavascriptInterface
        public void shareText(String title, String text) {
            runOnUiThread(() -> shareTextInternal(title, text));
        }

        @JavascriptInterface
        public void printCurrentPage() {
            runOnUiThread(() -> printWebView(target));
        }
    }

    private void saveDataUrlInternal(String dataUrl, String filename, String mimeType) {
        byte[] bytes = decodeDataUrl(dataUrl);
        if (bytes == null) {
            toast("تعذر قراءة الملف الذي تريد حفظه.");
            return;
        }
        String cleanName = safeLocalFilename(filename);
        String type = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Uri item = null;
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, cleanName);
                values.put(MediaStore.Downloads.MIME_TYPE, type);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ShamCash");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (item == null) throw new IllegalStateException("Could not create download");
                try (OutputStream out = getContentResolver().openOutputStream(item)) {
                    if (out == null) throw new IllegalStateException("Could not open download");
                    out.write(bytes);
                }
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(item, ready, null, null);
                toast("تم حفظ الملف في التنزيلات / ShamCash");
            } catch (Exception e) {
                if (item != null) {
                    try { getContentResolver().delete(item, null, null); } catch (Exception ignored) {}
                }
                toast("تعذر حفظ الملف. حاول استخدام زر المشاركة.");
            }
        } else {
            shareBytesWithChooser(bytes, cleanName, type, "حفظ الملف أو مشاركته", "ملف صادر من حاسبة شام كاش");
        }
    }

    private void shareDataUrlInternal(String dataUrl, String filename, String mimeType, String title, String text) {
        byte[] bytes = decodeDataUrl(dataUrl);
        if (bytes == null) {
            toast("تعذر إنشاء الملف للمشاركة.");
            return;
        }
        shareBytesWithChooser(bytes, safeLocalFilename(filename),
                (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType,
                (title == null || title.trim().isEmpty()) ? "مشاركة من حاسبة شام كاش" : title,
                text == null ? "" : text);
    }

    private void shareTextInternal(String title, String text) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "حاسبة شام كاش" : title);
        send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
        startActivity(Intent.createChooser(send, "مشاركة"));
    }

    private void shareBytesWithChooser(byte[] bytes, String filename, String mimeType, String title, String text) {
        try {
            File directory = new File(getCacheDir(), "share");
            if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("Cannot create cache folder");
            File file = new File(directory, filename);
            try (FileOutputStream out = new FileOutputStream(file, false)) { out.write(bytes); }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mimeType);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            if (text != null && !text.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, text);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(android.content.ClipData.newUri(getContentResolver(), filename, uri));
            startActivity(Intent.createChooser(send, title == null ? "مشاركة" : title));
        } catch (Exception e) {
            toast("تعذر فتح قائمة المشاركة.");
        }
    }

    private byte[] decodeDataUrl(String dataUrl) {
        try {
            if (dataUrl == null) return null;
            int comma = dataUrl.indexOf(',');
            if (comma < 0) return null;
            return Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
        } catch (Exception e) {
            return null;
        }
    }

    private String safeLocalFilename(String filename) {
        String name = filename == null ? "ShamCash_File" : filename.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        if (name.isEmpty() || name.equals(".") || name.equals("..")) name = "ShamCash_File";
        if (name.length() > 100) name = name.substring(name.length() - 100);
        return name;
    }

    private void printWebView(WebView target) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            toast("الطباعة غير مدعومة على هذا الإصدار من أندرويد.");
            return;
        }
        try {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String jobName = "ShamCash_" + stamp;
            PrintDocumentAdapter adapter = target.createPrintDocumentAdapter(jobName);
            PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("shamcash", "Sham Cash", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
            printManager.print(jobName, adapter, attributes);
        } catch (Exception e) {
            toast("تعذرت تهيئة الطباعة على هذا الجهاز.");
        }
    }

    private void toast(String text) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG).show());
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && pendingFileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            pendingFileCallback.onReceiveValue(results);
            pendingFileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (!popupDialogs.isEmpty()) {
            Dialog last = popupDialogs.get(popupDialogs.size() - 1);
            if (last.isShowing()) { last.dismiss(); return; }
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        for (Dialog dialog : new ArrayList<>(popupDialogs)) {
            try { if (dialog.isShowing()) dialog.dismiss(); } catch (Exception ignored) {}
        }
        if (webView != null) {
            try { webView.stopLoading(); webView.destroy(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
